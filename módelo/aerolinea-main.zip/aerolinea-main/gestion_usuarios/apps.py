from django.apps import AppConfig


class GestionUsuariosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gestion_usuarios'
